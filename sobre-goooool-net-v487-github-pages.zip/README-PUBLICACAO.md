# sobre.goooool.net — Livro digital do Goooool.net

Site estático multipágina, pronto para GitHub Pages.

- Base factual: Goooool.net V487
- Estrutura do save: 178
- Banco esportivo: revisão 378 / modelo 7
- Páginas indexáveis: 131
- Tópicos da Wiki transformados em páginas: 95
- Cenários com páginas próprias: 13
- Domínio configurado em `CNAME`: `sobre.goooool.net`
- Sitemap: `/sitemap.xml`
- Robots: `/robots.txt`

## Publicação no GitHub Pages

1. Envie **o conteúdo desta pasta** para a raiz do repositório.
2. Em Settings → Pages, publique a branch principal pela raiz (`/`).
3. O arquivo `CNAME` já contém `sobre.goooool.net`.
4. No DNS do domínio, crie o registro exigido pelo GitHub Pages para o subdomínio `sobre`.
5. Depois que o HTTPS estiver ativo, envie `https://sobre.goooool.net/sitemap.xml` ao Google Search Console e Bing Webmaster Tools.

## Fontes

- Wiki auditada: `js/wiki.js` da V487.
- Código atual do jogo, incluindo cenários em `js/career-scenarios.js`.
- Capturas reais extraídas do PDF/PPTX editorial fornecido pelo autor.
